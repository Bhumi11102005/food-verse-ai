# Food Verse AI – Multimodal Food Intelligence Agent

A student-friendly full-stack MVP built with **React + Vite** and **Python Flask**. It brings food recognition, nutrition estimation, freshness guidance, kitchen hygiene checks, cooking assistance, and personalized meal planning into one dashboard.

## Features
- **Food recognition & nutrition:** Upload a food image, choose/confirm the food, and view estimated calories and macros.
- **Freshness & spoilage guidance:** Upload an image and record storage/sensory observations. Optional Gemini Vision analysis is available when an API key is configured.
- **Restaurant hygiene:** Interactive kitchen hygiene checklist with a score and actionable reminders.
- **Smart cooking assistant:** Search recipes by ingredients and get practical cooking steps.
- **Personalized meal planner:** Generate a simple vegetarian/non-vegetarian sample day based on diet preference and calorie target.
- **Multimodal AI integration:** Optional Google Gemini Vision support for image-based food and freshness analysis. The app remains usable in demo mode without an API key.

## Tech stack
- Frontend: React 18, Vite, JavaScript, CSS
- Backend: Python 3, Flask, Flask-CORS
- Optional AI: Google Gemini API (set `GEMINI_API_KEY`)

## Project structure
```text
Food-Verse-AI/
├── backend/
│   ├── app.py
│   ├── food_data.py
│   ├── ai_service.py
│   └── requirements.txt
├── frontend/
│   ├── index.html
│   ├── package.json
│   └── src/
│       ├── main.jsx
│       ├── App.jsx
│       └── style.css
├── .gitignore
└── README.md
```

## Run locally

### 1. Backend
Open a terminal in the project folder:

```bash
cd backend
python -m venv venv
```

Activate the environment:

**Windows**
```bash
venv\Scripts\activate
```

**macOS/Linux**
```bash
source venv/bin/activate
```

Install packages and start Flask:

```bash
pip install -r requirements.txt
python app.py
```

Backend runs at `http://127.0.0.1:5000`.

### 2. Frontend
Open a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Open the local URL printed by Vite (usually `http://localhost:5173`).

## Optional Gemini Vision setup
1. Create an API key in Google AI Studio.
2. In the terminal where you start Flask, set the environment variable:

**macOS/Linux**
```bash
export GEMINI_API_KEY="your_api_key"
```

**Windows PowerShell**
```powershell
$env:GEMINI_API_KEY="your_api_key"
```

3. Restart the backend. Image analysis endpoints will then use Gemini. Never commit your API key to GitHub.

Without a key, the app uses clearly labelled demo estimates and rule-based guidance. These are not laboratory food-safety tests or medical nutrition advice.

## API endpoints
- `GET /api/health`
- `GET /api/foods`
- `POST /api/analyze-food` – multipart form: `image`, optional `food`
- `POST /api/freshness` – multipart form: `image`, `storage`, `smell`, `texture`
- `POST /api/hygiene-score` – JSON: `{ "checks": { "handwashing": true, ... } }`
- `POST /api/meal-plan` – JSON: `{ "diet": "vegetarian", "calories": 2000 }`
- `POST /api/cooking-assistant` – JSON: `{ "ingredients": "rice, tomato", "meal": "lunch" }`

## GitHub upload
1. Create a new **Public** or **Private** repository on GitHub named `food-verse-ai`.
2. Extract this ZIP.
3. Upload the project folder contents (not the ZIP itself) to the repository, or use Git:

```bash
git init
git add .
git commit -m "Initial Food Verse AI project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/food-verse-ai.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. Add the resulting repository URL to the GitHub Link field on Skill Wallet.

## Demo notes
- Use the food selector to confirm the item before interpreting estimated nutrition.
- The freshness module gives cautious guidance; if food smells unusual, has visible mould, damaged packaging, or uncertain storage history, do not taste it to test safety.
- The hygiene score is a self-audit checklist, not an official inspection certificate.
