FOODS = {
    "apple": {"category": "Fruit", "serving": "1 medium (182 g)", "calories": 95, "protein": 0.5, "carbs": 25, "fat": 0.3, "fiber": 4.4},
    "banana": {"category": "Fruit", "serving": "1 medium (118 g)", "calories": 105, "protein": 1.3, "carbs": 27, "fat": 0.4, "fiber": 3.1},
    "orange": {"category": "Fruit", "serving": "1 medium (131 g)", "calories": 62, "protein": 1.2, "carbs": 15.4, "fat": 0.2, "fiber": 3.1},
    "rice": {"category": "Grain", "serving": "1 cup cooked (158 g)", "calories": 205, "protein": 4.3, "carbs": 44.5, "fat": 0.4, "fiber": 0.6},
    "roti": {"category": "Grain", "serving": "1 medium", "calories": 110, "protein": 3, "carbs": 22, "fat": 1.5, "fiber": 3},
    "dal": {"category": "Legume", "serving": "1 cup cooked", "calories": 190, "protein": 12, "carbs": 30, "fat": 2, "fiber": 8},
    "paneer": {"category": "Dairy", "serving": "100 g", "calories": 265, "protein": 18, "carbs": 3.5, "fat": 20, "fiber": 0},
    "idli": {"category": "South Indian", "serving": "2 medium", "calories": 130, "protein": 4, "carbs": 26, "fat": 1, "fiber": 1.5},
    "dosa": {"category": "South Indian", "serving": "1 medium", "calories": 168, "protein": 4, "carbs": 28, "fat": 4, "fiber": 1.5},
    "poha": {"category": "Breakfast", "serving": "1 cup", "calories": 250, "protein": 5, "carbs": 45, "fat": 6, "fiber": 3},
    "chole": {"category": "Legume", "serving": "1 cup", "calories": 270, "protein": 13, "carbs": 45, "fat": 5, "fiber": 12},
    "salad": {"category": "Vegetable", "serving": "1 bowl", "calories": 70, "protein": 2, "carbs": 14, "fat": 1, "fiber": 4},
    "pizza": {"category": "Mixed dish", "serving": "1 medium slice", "calories": 285, "protein": 12, "carbs": 36, "fat": 10, "fiber": 2},
    "burger": {"category": "Mixed dish", "serving": "1 regular", "calories": 350, "protein": 15, "carbs": 40, "fat": 15, "fiber": 2},
    "oats": {"category": "Grain", "serving": "40 g dry", "calories": 150, "protein": 5, "carbs": 27, "fat": 3, "fiber": 4},
    "milk": {"category": "Dairy", "serving": "1 cup (244 ml)", "calories": 122, "protein": 8, "carbs": 12, "fat": 5, "fiber": 0}
}

RECIPES = [
    {"name": "Paneer bhurji", "ingredients": ["paneer", "onion", "tomato", "spices"], "time": "15 min", "steps": ["Crumble paneer.", "Sauté onion and tomato with spices.", "Add paneer and cook for 4–5 minutes.", "Serve with roti."], "tag": "High protein"},
    {"name": "Vegetable poha", "ingredients": ["poha", "onion", "peas", "peanuts"], "time": "20 min", "steps": ["Rinse poha briefly and drain.", "Sauté mustard seeds, onion, peas and peanuts.", "Add turmeric, poha and salt.", "Finish with lemon and coriander."], "tag": "Breakfast"},
    {"name": "Chole rice bowl", "ingredients": ["chole", "rice", "tomato", "onion"], "time": "25 min", "steps": ["Prepare or warm cooked chickpeas with masala.", "Serve over cooked rice.", "Add cucumber or salad on the side."], "tag": "Filling meal"},
    {"name": "Banana oats smoothie", "ingredients": ["banana", "oats", "milk"], "time": "5 min", "steps": ["Add banana, oats and chilled milk to a blender.", "Blend until smooth.", "Serve immediately."], "tag": "Quick snack"},
    {"name": "Masala vegetable dal", "ingredients": ["dal", "tomato", "onion", "vegetables"], "time": "30 min", "steps": ["Cook washed dal until soft.", "Prepare a tomato-onion tempering.", "Add vegetables and simmer until cooked.", "Combine with dal and adjust seasoning."], "tag": "Everyday meal"}
]
