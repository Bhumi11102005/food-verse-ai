from flask import Flask, request, jsonify
from flask_cors import CORS
from PIL import Image
from io import BytesIO
from food_data import FOODS, RECIPES
from ai_service import gemini_image_analysis

app = Flask(__name__)
CORS(app)
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024

def read_image(field="image"):
    file = request.files.get(field)
    if not file:
        return None, None, None
    raw = file.read()
    try:
        img = Image.open(BytesIO(raw))
        img.verify()
        return raw, file.mimetype or "image/jpeg", img.format
    except Exception:
        return None, None, None

@app.get("/api/health")
def health():
    return jsonify({"status": "ok", "service": "Food Verse AI API"})

@app.get("/api/foods")
def foods():
    return jsonify(FOODS)

@app.post("/api/analyze-food")
def analyze_food():
    raw, mime, fmt = read_image()
    if raw is None:
        return jsonify({"error": "Please upload a valid image file."}), 400
    selected = (request.form.get("food") or "").strip().lower()
    ai_text = gemini_image_analysis(
        raw, mime,
        "Identify the visible food items in this image. Return a concise likely food name, "
        "visible ingredients if clear, and uncertainty. Do not claim exact portion size. "
        "This is an educational estimate, not medical advice."
    )
    food_key = selected if selected in FOODS else None
    if not food_key and ai_text:
        for name in FOODS:
            if name in ai_text.lower():
                food_key = name
                break
    if not food_key:
        food_key = selected if selected in FOODS else "rice"
    item = FOODS[food_key]
    return jsonify({
        "food": food_key.title(),
        "category": item["category"],
        "serving": item["serving"],
        "nutrition": item,
        "ai_analysis": ai_text,
        "mode": "Gemini Vision" if ai_text else "Demo estimate",
        "notice": "Nutrition values are approximate and depend on recipe, oil, ingredients and portion size."
    })

@app.post("/api/freshness")
def freshness():
    raw, mime, fmt = read_image()
    if raw is None:
        return jsonify({"error": "Please upload a valid image file."}), 400
    storage = request.form.get("storage", "unknown")
    smell = request.form.get("smell", "normal")
    texture = request.form.get("texture", "normal")
    prompt = ("Describe only visible signs that may indicate food deterioration in this image. "
              "Do not certify food as safe. Mention that smell, storage history and temperature "
              "cannot be reliably verified from an image.")
    ai_text = gemini_image_analysis(raw, mime, prompt)
    concerns = []
    if smell == "unusual": concerns.append("An unusual smell is a warning sign.")
    if texture == "slimy": concerns.append("A slimy texture is a warning sign.")
    if storage == "room_temp_long": concerns.append("Food left at room temperature for a long time may be unsafe.")
    if not concerns:
        concerns.append("No warning was selected, but this does not prove the food is safe.")
    return jsonify({
        "status": "Caution – verify before use",
        "observations": concerns,
        "ai_analysis": ai_text,
        "mode": "Gemini Vision" if ai_text else "Rule-based guidance",
        "safety": "Never taste food to check whether it is safe. Discard food with mould, unusual odour, damaged packaging or uncertain time/temperature history. When in doubt, throw it out."
    })

@app.post("/api/hygiene-score")
def hygiene_score():
    data = request.get_json(silent=True) or {}
    checks = data.get("checks", {})
    if not isinstance(checks, dict) or not checks:
        return jsonify({"error": "Provide hygiene checklist values."}), 400
    total = len(checks)
    passed = sum(1 for value in checks.values() if value)
    score = round((passed / total) * 100)
    tips = []
    if not checks.get("handwashing"): tips.append("Wash hands with soap before food preparation and after handling raw food.")
    if not checks.get("surface_cleaning"): tips.append("Clean and sanitize food-contact surfaces.")
    if not checks.get("temperature"): tips.append("Check refrigeration and hot-holding temperatures with a food thermometer.")
    if not checks.get("separation"): tips.append("Separate raw and ready-to-eat foods to prevent cross-contamination.")
    if not checks.get("pest_control"): tips.append("Keep food covered and maintain pest-control practices.")
    if not tips: tips.append("Keep records and repeat the checklist regularly.")
    return jsonify({"score": score, "passed": passed, "total": total, "tips": tips,
                    "notice": "Self-audit only; this is not an official food-safety inspection."})

@app.post("/api/meal-plan")
def meal_plan():
    data = request.get_json(silent=True) or {}
    diet = data.get("diet", "vegetarian")
    try: target = max(1200, min(4000, int(data.get("calories", 2000))))
    except (ValueError, TypeError): target = 2000
    veg = [
        ("Breakfast", "Poha with peanuts + milk", 400),
        ("Mid-morning", "Banana + handful of nuts", 220),
        ("Lunch", "Dal, rice, roti and salad", 600),
        ("Evening snack", "Curd or paneer sandwich", 300),
        ("Dinner", "Paneer/vegetable curry with roti", 480)
    ]
    nonveg = [
        ("Breakfast", "Egg omelette, toast and fruit", 400),
        ("Mid-morning", "Yogurt and nuts", 220),
        ("Lunch", "Chicken curry, rice and salad", 600),
        ("Evening snack", "Fruit and roasted chana", 300),
        ("Dinner", "Dal, roti and egg/chicken portion", 480)
    ]
    meals = veg if diet == "vegetarian" else nonveg
    base = sum(x[2] for x in meals)
    scale = target / base
    result = [{"time": t, "meal": m, "calories": round(c * scale)} for t,m,c in meals]
    return jsonify({"diet": diet, "target_calories": target, "meals": result,
                    "estimated_total": sum(x["calories"] for x in result),
                    "notice": "Illustrative meal plan only. Calorie needs vary by age, body size, activity and health. Consult a qualified dietitian for a clinical plan."})

@app.post("/api/cooking-assistant")
def cooking_assistant():
    data = request.get_json(silent=True) or {}
    ingredients = [x.strip().lower() for x in data.get("ingredients", "").split(",") if x.strip()]
    matches = []
    for recipe in RECIPES:
        overlap = [x for x in ingredients if any(x in ing or ing in x for ing in recipe["ingredients"])]
        if overlap:
            matches.append({**recipe, "matched": overlap})
    if not matches:
        matches = RECIPES[:2]
    return jsonify({"recipes": matches[:4], "message": "Recipe ideas based on the ingredients entered."})

@app.errorhandler(413)
def too_large(_):
    return jsonify({"error": "Image is too large. Please use an image under 8 MB."}), 413

if __name__ == "__main__":
    app.run(debug=True, port=5000)
