import os, base64, requests

def gemini_image_analysis(image_bytes, mime_type, prompt):
    """Optional Gemini Vision call. Returns None when no key or request fails."""
    key = os.getenv("GEMINI_API_KEY")
    if not key:
        return None
    try:
        encoded = base64.b64encode(image_bytes).decode("utf-8")
        url = ("https://generativelanguage.googleapis.com/v1beta/models/"
               "gemini-2.0-flash:generateContent?key=" + key)
        payload = {
            "contents": [{
                "parts": [
                    {"text": prompt},
                    {"inline_data": {"mime_type": mime_type, "data": encoded}}
                ]
            }]
        }
        response = requests.post(url, json=payload, timeout=35)
        response.raise_for_status()
        data = response.json()
        return data["candidates"][0]["content"]["parts"][0]["text"]
    except Exception:
        return None
