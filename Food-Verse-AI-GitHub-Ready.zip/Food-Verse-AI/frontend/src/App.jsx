import React, { useEffect, useMemo, useState } from "react";
import { Activity, Apple, Camera, ChefHat, ClipboardCheck, Leaf, Menu, Salad, ShieldCheck, Sparkles, Upload, Utensils, X, CheckCircle2, AlertTriangle } from "lucide-react";

const API = "http://127.0.0.1:5000/api";
const nav = [
  ["Overview", "overview"], ["Food & Nutrition", "food"], ["Freshness Check", "freshness"],
  ["Kitchen Hygiene", "hygiene"], ["Meal Planner", "meal"], ["Cooking Assistant", "cook"]
];
const foodOptions = ["apple","banana","orange","rice","roti","dal","paneer","idli","dosa","poha","chole","salad","pizza","burger","oats","milk"];
const checksList = [
  ["handwashing","Handwashing station is available and used"],
  ["surface_cleaning","Food preparation surfaces are clean"],
  ["temperature","Food storage temperatures are checked"],
  ["separation","Raw and ready-to-eat foods are separated"],
  ["pest_control","Food is covered and pest control is maintained"],
  ["protective_clothing","Clean apron / hair covering is used"]
];

function App() {
  const [page,setPage] = useState("overview");
  const [mobileOpen,setMobileOpen] = useState(false);
  const [health,setHealth] = useState("checking");
  const [food,setFood] = useState("poha");
  const [foodFile,setFoodFile] = useState(null);
  const [foodPreview,setFoodPreview] = useState("");
  const [foodResult,setFoodResult] = useState(null);
  const [freshFile,setFreshFile] = useState(null);
  const [freshPreview,setFreshPreview] = useState("");
  const [freshResult,setFreshResult] = useState(null);
  const [storage,setStorage] = useState("fridge");
  const [smell,setSmell] = useState("normal");
  const [texture,setTexture] = useState("normal");
  const [checks,setChecks] = useState(Object.fromEntries(checksList.map(([k])=>[k,false])));
  const [hygieneResult,setHygieneResult] = useState(null);
  const [diet,setDiet] = useState("vegetarian");
  const [calories,setCalories] = useState(2000);
  const [mealResult,setMealResult] = useState(null);
  const [ingredients,setIngredients] = useState("paneer, tomato, onion");
  const [recipes,setRecipes] = useState([]);
  const [loading,setLoading] = useState(false);
  const [error,setError] = useState("");

  useEffect(()=>{ fetch(`${API}/health`).then(r=>r.json()).then(()=>setHealth("online")).catch(()=>setHealth("offline")); },[]);
  const pageTitle = nav.find(x=>x[1]===page)?.[0] || "Overview";
  const stats = useMemo(()=>[
    {label:"Food database",value:"16",sub:"Everyday food items",icon:Apple},
    {label:"AI modules",value:"5",sub:"Connected workflows",icon:Sparkles},
    {label:"Hygiene checks",value:"6",sub:"Kitchen self-audit",icon:ShieldCheck},
    {label:"Recipe ideas",value:"5",sub:"Starter recipes",icon:ChefHat}
  ],[]);
  const go = (p)=>{setPage(p);setMobileOpen(false);setError("");};

  async function post(path, body, isForm=false) {
    const res = await fetch(`${API}${path}`, {method:"POST", body:isForm?body:JSON.stringify(body), headers:isForm?{}:{"Content-Type":"application/json"}});
    const data = await res.json();
    if(!res.ok) throw new Error(data.error || "Something went wrong");
    return data;
  }
  function filePick(e, type) {
    const f=e.target.files?.[0]; if(!f) return;
    if(type==="food"){setFoodFile(f);setFoodPreview(URL.createObjectURL(f));setFoodResult(null);}
    else {setFreshFile(f);setFreshPreview(URL.createObjectURL(f));setFreshResult(null);}
  }
  async function analyzeFood(e){e.preventDefault(); if(!foodFile){setError("Please upload a food image first.");return;} setLoading(true);setError("");try{const fd=new FormData();fd.append("image",foodFile);fd.append("food",food);setFoodResult(await post("/analyze-food",fd,true));}catch(err){setError(err.message);}finally{setLoading(false);}}
  async function analyzeFresh(e){e.preventDefault();if(!freshFile){setError("Please upload an image first.");return;}setLoading(true);setError("");try{const fd=new FormData();fd.append("image",freshFile);fd.append("storage",storage);fd.append("smell",smell);fd.append("texture",texture);setFreshResult(await post("/freshness",fd,true));}catch(err){setError(err.message);}finally{setLoading(false);}}
  async function scoreHygiene(){setLoading(true);setError("");try{setHygieneResult(await post("/hygiene-score",{checks}));}catch(err){setError(err.message);}finally{setLoading(false);}}
  async function makePlan(){setLoading(true);setError("");try{setMealResult(await post("/meal-plan",{diet,calories}));}catch(err){setError(err.message);}finally{setLoading(false);}}
  async function findRecipes(){setLoading(true);setError("");try{const d=await post("/cooking-assistant",{ingredients});setRecipes(d.recipes);}catch(err){setError(err.message);}finally{setLoading(false);}}

  return <div className="app-shell">
    <aside className={`sidebar ${mobileOpen?"open":""}`}>
      <div className="brand"><div className="brand-mark"><Salad size={22}/></div><div><b>food verse</b><span>AI INTELLIGENCE</span></div><button className="close-nav" onClick={()=>setMobileOpen(false)}><X size={18}/></button></div>
      <div className="nav-label">WORKSPACE</div>
      {nav.map(([label,id],i)=><button key={id} className={`nav-item ${page===id?"active":""}`} onClick={()=>go(id)}><span className="nav-icon">{[<Activity/>,<Apple/>,<ShieldCheck/>,<ClipboardCheck/>,<Leaf/>,<ChefHat/>][i]}</span>{label}</button>)}
      <div className="sidebar-bottom"><div className="mini-leaf"><Leaf size={17}/></div><b>Eat smarter. Live better.</b><p>Food insights for everyday decisions.</p><span className={`api-status ${health}`}></span> API {health==="online"?"connected":health==="offline"?"offline":"checking"}
      </div>
    </aside>
    {mobileOpen&&<div className="scrim" onClick={()=>setMobileOpen(false)} />}
    <main className="main">
      <header className="topbar"><button className="mobile-menu" onClick={()=>setMobileOpen(true)}><Menu/></button><div><span className="eyebrow">FOOD INTELLIGENCE PLATFORM</span><h1>{pageTitle}</h1></div><div className="top-right"><span className="live-dot"></span><span>Demo workspace</span><div className="avatar">FV</div></div></header>
      <div className="content">
        {error&&<div className="alert error"><AlertTriangle size={18}/>{error}<button onClick={()=>setError("")}>Dismiss</button></div>}
        {page==="overview"&&<><section className="hero"><div className="hero-copy"><span className="hero-tag"><Sparkles size={14}/> MULTIMODAL FOOD INTELLIGENCE</span><h2>Understand your food.<br/><em>Make better choices.</em></h2><p>One smart workspace for food recognition, nutrition insights, freshness guidance and kitchen wellness.</p><button className="primary-btn" onClick={()=>go("food")}>Explore food analysis <span>→</span></button></div><div className="hero-art"><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div><div className="food-emoji">🥑</div><div className="float-card card-a"><span>✦</span> Nutrition insights</div><div className="float-card card-b">🌱 Fresh choices</div><div className="float-card card-c">♡ Smart kitchen</div></div></section>
          <div className="section-heading"><div><span className="eyebrow">YOUR WORKSPACE</span><h3>Platform at a glance</h3></div><span className="muted">All modules in one place</span></div>
          <div className="stats-grid">{stats.map(({label,value,sub,icon:Icon})=><div className="stat-card" key={label}><div className="stat-top"><span>{label}</span><Icon size={19}/></div><strong>{value}</strong><small>{sub}</small></div>)}</div>
          <div className="section-heading"><div><span className="eyebrow">GET STARTED</span><h3>Explore intelligence modules</h3></div></div>
          <div className="module-grid">{nav.slice(1).map(([label,id],i)=>{const icons=[Camera,ShieldCheck,ClipboardCheck,Leaf,ChefHat],Icon=icons[i];const desc=["Identify food and explore estimated calories & macros.","Review food condition and learn safe handling practices.","Run a simple hygiene self-audit for your kitchen.","Create a sample meal plan around your diet preference.","Find practical recipes from ingredients you already have."][i];return <button className="module-card" key={id} onClick={()=>go(id)}><div className={`module-icon color-${i}`}><Icon/></div><h4>{label}</h4><p>{desc}</p><span className="module-link">Open module <b>↗</b></span></button>})}</div>
          <div className="notice"><ShieldCheck size={18}/><p><b>Responsible AI:</b> Food and nutrition outputs are estimates. Image analysis cannot certify food safety or replace professional advice.</p></div>
        </>}
        {page==="food"&&<><div className="page-intro"><span className="eyebrow">VISION + NUTRITION</span><h2>Food recognition & nutrition</h2><p>Upload a food photo, confirm the food item, and explore an approximate nutrition profile.</p></div><div className="two-col"><form className="panel" onSubmit={analyzeFood}><h3><Camera size={19}/> Food image</h3><label className="upload-box">{foodPreview?<img src={foodPreview} alt="Food preview"/>:<><Upload size={26}/><b>Drop a food image here</b><span>or browse files · JPG, PNG, WEBP · max 8 MB</span></>}<input type="file" accept="image/*" onChange={e=>filePick(e,"food")}/></label><label className="field-label">Confirm food item</label><select value={food} onChange={e=>setFood(e.target.value)}>{foodOptions.map(x=><option key={x} value={x}>{x[0].toUpperCase()+x.slice(1)}</option>)}</select><button className="primary-btn full" disabled={loading}>{loading?"Analyzing…":"Analyze food →"}</button></form>
          <div className="panel result-panel"><h3><Activity size={19}/> Nutrition insights</h3>{foodResult?<><div className="result-heading"><div className="result-food-icon">🥗</div><div><h2>{foodResult.food}</h2><span>{foodResult.category} · {foodResult.serving}</span></div><span className="mode-pill">{foodResult.mode}</span></div><div className="calorie-box"><span>Estimated energy</span><strong>{foodResult.nutrition.calories}<small> kcal</small></strong></div><div className="macro-grid">{[["Protein",foodResult.nutrition.protein+" g"],["Carbs",foodResult.nutrition.carbs+" g"],["Fat",foodResult.nutrition.fat+" g"],["Fiber",foodResult.nutrition.fiber+" g"]].map(([a,b])=><div key={a}><span>{a}</span><b>{b}</b></div>)}</div>{foodResult.ai_analysis&&<p className="ai-note">{foodResult.ai_analysis}</p>}<p className="fine-print">{foodResult.notice}</p></>:<div className="empty-state"><div>🍽️</div><b>Your nutrition report will appear here</b><p>Upload an image and confirm the food item to get started.</p></div>}</div></div></>}
        {page==="freshness"&&<><div className="page-intro"><span className="eyebrow">FOOD QUALITY</span><h2>Freshness & spoilage guidance</h2><p>Combine image observations with storage and sensory information. An image alone cannot prove food is safe.</p></div><div className="two-col"><form className="panel" onSubmit={analyzeFresh}><h3><Camera size={19}/> Inspect food</h3><label className="upload-box compact">{freshPreview?<img src={freshPreview} alt="Freshness preview"/>:<><Upload size={25}/><b>Upload food image</b><span>JPG, PNG, WEBP · max 8 MB</span></>}<input type="file" accept="image/*" onChange={e=>filePick(e,"fresh")}/></label><label className="field-label">Storage history</label><select value={storage} onChange={e=>setStorage(e.target.value)}><option value="fridge">Refrigerated properly</option><option value="room_temp_long">Left at room temperature for a long time</option><option value="unknown">Not sure</option></select><label className="field-label">Smell</label><select value={smell} onChange={e=>setSmell(e.target.value)}><option value="normal">Normal</option><option value="unusual">Unusual / off odour</option><option value="unknown">Not checked</option></select><label className="field-label">Texture</label><select value={texture} onChange={e=>setTexture(e.target.value)}><option value="normal">Normal</option><option value="slimy">Slimy / unusual</option><option value="unknown">Not sure</option></select><button className="primary-btn full" disabled={loading}>{loading?"Checking…":"Review observations →"}</button></form><div className="panel result-panel"><h3><ShieldCheck size={19}/> Assessment</h3>{freshResult?<><div className="fresh-warning"><AlertTriangle/><div><b>{freshResult.status}</b><span>{freshResult.mode}</span></div></div><ul className="insight-list">{freshResult.observations.map((x,i)=><li key={i}>{x}</li>)}</ul>{freshResult.ai_analysis&&<p className="ai-note">{freshResult.ai_analysis}</p>}<div className="safety-note"><b>Food safety first</b><p>{freshResult.safety}</p></div></>:<div className="empty-state"><div>🍓</div><b>Food condition report</b><p>Share the image and observations to receive cautious guidance.</p></div>}</div></div></>}
        {page==="hygiene"&&<><div className="page-intro"><span className="eyebrow">SMART KITCHEN</span><h2>Restaurant hygiene self-audit</h2><p>Mark the practices currently in place to calculate a simple checklist completion score.</p></div><div className="two-col"><div className="panel"><h3><ClipboardCheck size={19}/> Daily hygiene checklist</h3><div className="check-list">{checksList.map(([key,label])=><label className="check-row" key={key}><input type="checkbox" checked={checks[key]} onChange={e=>setChecks({...checks,[key]:e.target.checked})}/><span className="fake-check"><CheckCircle2/></span><span>{label}</span></label>)}</div><button className="primary-btn full" disabled={loading} onClick={scoreHygiene}>{loading?"Calculating…":"Calculate hygiene score →"}</button></div><div className="panel result-panel"><h3><ShieldCheck size={19}/> Hygiene score</h3>{hygieneResult?<><div className="score-ring" style={{"--score":`${hygieneResult.score}%`}}><div><strong>{hygieneResult.score}%</strong><span>completed</span></div></div><p className="center muted">{hygieneResult.passed} of {hygieneResult.total} practices marked complete</p><h4>Suggested actions</h4><ul className="insight-list">{hygieneResult.tips.map((t,i)=><li key={i}>{t}</li>)}</ul><p className="fine-print">{hygieneResult.notice}</p></>:<div className="empty-state"><div>🧼</div><b>Your kitchen score appears here</b><p>Complete the checklist and calculate your score.</p></div>}</div></div></>}
        {page==="meal"&&<><div className="page-intro"><span className="eyebrow">PERSONALIZED PLANNING</span><h2>Your meal planner</h2><p>Generate a sample day of meals based on a selected diet and calorie target.</p></div><div className="two-col"><div className="panel"><h3><Leaf size={19}/> Your preferences</h3><label className="field-label">Diet preference</label><select value={diet} onChange={e=>setDiet(e.target.value)}><option value="vegetarian">Vegetarian</option><option value="non-vegetarian">Non-vegetarian</option></select><label className="field-label">Daily calorie target</label><div className="range-value">{calories.toLocaleString()} <small>kcal / day</small></div><input className="range" type="range" min="1200" max="3500" step="100" value={calories} onChange={e=>setCalories(Number(e.target.value))}/><div className="range-labels"><span>1,200 kcal</span><span>3,500 kcal</span></div><button className="primary-btn full" disabled={loading} onClick={makePlan}>{loading?"Creating…":"Generate meal plan →"}</button></div><div className="panel result-panel"><h3><Utensils size={19}/> Daily meal plan</h3>{mealResult?<><div className="plan-total"><span>Estimated daily total</span><b>{mealResult.estimated_total.toLocaleString()} kcal</b></div><div className="timeline">{mealResult.meals.map((m,i)=><div className="meal-row" key={i}><div className="timeline-dot"></div><div><span>{m.time}</span><b>{m.meal}</b></div><strong>{m.calories} kcal</strong></div>)}</div><p className="fine-print">{mealResult.notice}</p></>:<div className="empty-state"><div>🥙</div><b>Your daily plan will appear here</b><p>Choose your preferences and generate a sample plan.</p></div>}</div></div></>}
        {page==="cook"&&<><div className="page-intro"><span className="eyebrow">YOUR KITCHEN COMPANION</span><h2>Smart cooking assistant</h2><p>Enter ingredients separated by commas and discover simple recipe ideas.</p></div><div className="panel cooking-search"><h3><ChefHat size={19}/> What do you have?</h3><textarea value={ingredients} onChange={e=>setIngredients(e.target.value)} placeholder="e.g. paneer, tomato, onion, rice"/><button className="primary-btn" disabled={loading} onClick={findRecipes}>{loading?"Finding ideas…":"Find recipes →"}</button></div><div className="recipe-grid">{recipes.map((r,i)=><article className="recipe-card" key={r.name}><div className={`recipe-art art-${i%4}`}>{["🥘","🥣","🍛","🥤"][i%4]}</div><div className="recipe-body"><div className="recipe-meta"><span>{r.tag}</span><span>◷ {r.time}</span></div><h3>{r.name}</h3><p className="matched">Matched: {r.matched?.join(", ")}</p><ol>{r.steps.map((s,j)=><li key={j}>{s}</li>)}</ol></div></article>)}</div>{!recipes.length&&<div className="empty-wide">Recipe suggestions will appear here after you search.</div>}</>}
        <footer className="footer"><span>FOOD VERSE AI</span><span>Built for smarter food decisions · Student project MVP</span></footer>
      </div>
    </main>
  </div>;
}
export default App;
